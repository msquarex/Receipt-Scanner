typedef ObjectMapper<T> = T Function(
  Map<String, dynamic>? data,
  String? documentId,
);
