package com.example.daily_expense_tracker_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
