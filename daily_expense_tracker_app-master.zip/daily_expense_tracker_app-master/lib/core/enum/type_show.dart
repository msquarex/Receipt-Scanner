enum TypeShow { all, limit }
