class AppFontSize {
  static const double small = 12;
  static const double medium = 14;
  static const double large = 16;
  static const double xLarge = 18;
  static const double xxLarge = 20;
  static const double xxxLarge = 22;
  static const double xxxxLarge = 24;
  static const double xxxxxLarge = 26;
  static const double xxxxxxLarge = 28;
  static const double xxxxxxxLarge = 30;
  static const double xxxxxxxxLarge = 32;
}
